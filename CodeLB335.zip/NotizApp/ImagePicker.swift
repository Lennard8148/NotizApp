import SwiftUI
import UIKit

struct ImagePicker: UIViewControllerRepresentable {
    var sourceType: UIImagePickerController.SourceType = .photoLibrary
    var completionHandler: (Data?) -> Void

    func makeUIViewController(context: Context) -> UIImagePickerController {
        let picker = UIImagePickerController()
        picker.sourceType = sourceType
        picker.delegate = context.coordinator
        return picker
    }

    func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {
    }
    
    func makeCoordinator() -> Coordinator {
        Coordinator(self, completionHandler: completionHandler)
    }

    class Coordinator: NSObject, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
        let parent: ImagePicker
        let completionHandler: (Data?) -> Void

        init(_ parent: ImagePicker, completionHandler: @escaping (Data?) -> Void) {
            self.parent = parent
            self.completionHandler = completionHandler
        }

        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
            completionHandler(nil)
            picker.dismiss(animated: true)
        }

        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
            var imageData: Data? = nil
            if let image = info[.originalImage] as? UIImage {
                imageData = image.jpegData(compressionQuality: 0.8)
            }
            completionHandler(imageData)
            picker.dismiss(animated: true)
        }
    }
}
