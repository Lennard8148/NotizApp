import SwiftUI
import SwiftData

struct NewNoteView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.modelContext) private var context

    @State private var title: String = ""
    @State private var content: String = ""
    @State private var imagesData: [Data] = []
    @State private var showImagePicker = false
    @State private var showCamera = false
    @State private var imageSourceType: UIImagePickerController.SourceType = .photoLibrary

    var body: some View {
        VStack {
            TextField("Titel", text: $title)
                .font(.title)
                .padding()
            
            TextEditor(text: $content)
                .padding()
            
            ScrollView(.horizontal) {
                HStack {
                    ForEach(imagesData, id: \.self) { data in
                        if let uiImage = UIImage(data: data) {
                            Image(uiImage: uiImage)
                                .resizable()
                                .scaledToFit()
                                .frame(height: 100)
                        }
                    }
                }
            }
            
            HStack {
                Button(action: {
                    imageSourceType = .photoLibrary
                    showImagePicker = true
                }) {
                    Text("Bild aus Dateien auswählen")
                }
                Button(action: {
                    imageSourceType = .camera
                    showImagePicker = true
                }) {
                    Text("Bild mit Kamera aufnehmen")
                }
            }
            .padding()
            
            Spacer()
        }
        .navigationTitle("Neue Notiz")
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Button("Speichern") {
                    saveNote()
                }
                .disabled(title.isEmpty && content.isEmpty)
            }
        }
        .sheet(isPresented: $showImagePicker) {
            ImagePicker(sourceType: imageSourceType) { imageData in
                if let data = imageData {
                    imagesData.append(data)
                }
            }
        }
    }
    
    private func saveNote() {
        let newNote = Note(title: title, content: content)
        context.insert(newNote)
        
        for data in imagesData {
            let image = ImageData(data: data)
            image.note = newNote
            context.insert(image)
            newNote.images.append(image)
        }
        
        dismiss()
    }
}
