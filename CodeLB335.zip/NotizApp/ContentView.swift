import SwiftUI
import SwiftData

struct ContentView: View {
    @Environment(\.modelContext) private var context
    @Query(sort: [SortDescriptor(\Note.createdAt, order: .reverse)]) private var notes: [Note]
    
    var body: some View {
        NavigationStack {
            VStack {
                Text("Notizen")
                    .font(.largeTitle)
                    .bold()
                    .padding()
                
                List {
                    ForEach(notes) { note in
                        NavigationLink(destination: NoteDetailView(note: note)) {
                            Text(note.title)
                        }
                    }
                    .onDelete(perform: deleteNote)
                }
                .listStyle(.plain)
            }
            .toolbar {
                ToolbarItem(placement: .bottomBar) {
                    HStack {
                        Spacer()
                        NavigationLink(destination: NewNoteView()) {
                            Image(systemName: "plus.circle.fill")
                                .foregroundColor(.orange)
                                .font(.largeTitle)
                        }
                    }
                }
            }
        }
    }
    
    private func deleteNote(at offsets: IndexSet) {
        for index in offsets {
            let note = notes[index]
            context.delete(note)
        }
    }
}
