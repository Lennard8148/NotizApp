import SwiftData
import Foundation

@Model
class ImageData: Identifiable {
    var data: Data
    @Relationship var note: Note?
    
    init(data: Data, note: Note? = nil) {
        self.data = data
        self.note = note
    }
}

