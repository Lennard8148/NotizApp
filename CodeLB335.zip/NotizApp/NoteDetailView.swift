import SwiftUI
import SwiftData

struct NoteDetailView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.modelContext) private var context

    @Bindable var note: Note

    @State private var showDeleteConfirmation = false
    @FocusState private var isWriting: Bool
    @State private var showImagePicker = false
    @State private var imageSourceType: UIImagePickerController.SourceType = .photoLibrary

    var body: some View {
        VStack {
            TextField("Titel", text: $note.title)
                .font(.title)
                .padding()
            
            TextEditor(text: $note.content)
                .padding()
                .focused($isWriting)
            
            ScrollView(.horizontal) {
                HStack {
                    ForEach(note.images) { imageData in
                        if let uiImage = UIImage(data: imageData.data) {
                            Image(uiImage: uiImage)
                                .resizable()
                                .scaledToFit()
                                .frame(height: 100)
                        }
                    }
                }
            }
            
            HStack {
                Button(action: {
                    imageSourceType = .photoLibrary
                    showImagePicker = true
                }) {
                    Text("Bild hinzufügen")
                }
                Button(action: {
                    imageSourceType = .camera
                    showImagePicker = true
                }) {
                    Text("Foto aufnehmen")
                }
            }
            .padding()
            
            Spacer()
        }
        .navigationBarBackButtonHidden(true)
        .toolbar {
            ToolbarItem(placement: .navigationBarLeading) {
                Button("Zurück") {
                    dismiss()
                }
            }
            ToolbarItem(placement: .navigationBarTrailing) {
                Button("Löschen") {
                    showDeleteConfirmation = true
                }
            }
            ToolbarItem(placement: .bottomBar) {
                HStack {
                    Button("Schreiben") {
                        isWriting = true
                    }
                    Spacer()
                }
            }
        }
        .alert("Möchten Sie die Notiz wirklich löschen?", isPresented: $showDeleteConfirmation) {
            Button("Ja", role: .destructive) {
                context.delete(note)
                dismiss()
            }
            Button("Nein", role: .cancel) { }
        }
        .sheet(isPresented: $showImagePicker) {
            ImagePicker(sourceType: imageSourceType) { imageData in
                if let data = imageData {
                    let image = ImageData(data: data)
                    image.note = note
                    context.insert(image)
                    note.images.append(image)
                }
            }
        }
    }
}
