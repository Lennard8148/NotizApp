import SwiftData
import Foundation

@Model
class Note: Identifiable {
    var title: String
    var content: String
    var createdAt: Date
    @Relationship(deleteRule: .cascade, inverse: \ImageData.note) var images: [ImageData] = []
    
    init(title: String, content: String, createdAt: Date = Date()) {
        self.title = title
        self.content = content
        self.createdAt = createdAt
    }
}
