import SwiftUI
import SwiftData

@main
struct NotizAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
        .modelContainer(for: [Note.self, ImageData.self])
    }
}
