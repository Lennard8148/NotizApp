//
//  NotizAppTests.swift
//  NotizAppTests
//
//  Created by lennard buehler on 23.09.2024.
//

import Testing
@testable import NotizApp

struct NotizAppTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
